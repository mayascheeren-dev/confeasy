# Confeasy — pacote corrigido para GitHub + Vercel

## Correção desta versão

O erro mostrado no Vercel foi:

`[vite:build-html] Falha ao resolver /src/main.jsx de /vercel/path0/index.html`

Isso significa que o `index.html` estava apontando para `/src/main.jsx`, mas esse arquivo não estava presente no projeto que chegou ao Vercel/GitHub no momento do build.

Este pacote contém obrigatoriamente:

```text
index.html
package.json
vite.config.js
src/
  App.jsx
  main.jsx
  index.css
  lib/
    supabase.js
api/
  provision-user.js
supabase/
  schema.sql
```

## Como colocar no GitHub

1. Entre no repositório `mayascheeren-dev/confeasy`.
2. Substitua os arquivos antigos pelos arquivos desta pasta.
3. Confirme que `src/main.jsx` aparece no GitHub exatamente com esse nome e dentro de `src`.
4. Confirme também `src/lib/supabase.js`.
5. Faça Commit.

O `index.html` usa:

```html
<script type="module" src="/src/main.jsx"></script>
```

Portanto, não renomeie `main.jsx` para `main.js`, `Main.jsx` ou coloque-o fora de `src`. Em ambientes Linux como o build do Vercel, maiúsculas/minúsculas importam.

## Vercel

Build Command: `npm run build`
Output Directory: `dist`
Framework: Vite

Variáveis de ambiente necessárias:

```text
VITE_SUPABASE_URL
VITE_SUPABASE_PUBLISHABLE_KEY
SUPABASE_SERVICE_ROLE_KEY
CONFEASY_ADMIN_SECRET
```

As duas primeiras são usadas pelo frontend. As duas últimas são somente para a função serverless de provisionamento de clientes.

NUNCA coloque `SUPABASE_SERVICE_ROLE_KEY` com prefixo `VITE_`.

## Importante

O projeto precisa ser implantado com a raiz do repositório contendo `package.json` e `index.html`. Não configure o Vercel para uma pasta acima/abaixo que não contenha esses arquivos.

## Validação

Depois do commit, o Vercel deve executar:

```bash
npm install
npm run build
```

O resultado esperado é uma pasta `dist/` sem erro de resolução de `/src/main.jsx`.
