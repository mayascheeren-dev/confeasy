import { createClient } from '@supabase/supabase-js';
import crypto from 'node:crypto';

const supabaseAdmin = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { autoRefreshToken: false, persistSession: false } }
);

function password() {
  return `Conf-${crypto.randomBytes(7).toString('base64url')}-9!`;
}
function addYear() {
  const d = new Date(); d.setDate(d.getDate() + 365); return d.toISOString().slice(0,10);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (req.headers.authorization !== `Bearer ${process.env.CONFEASY_ADMIN_SECRET}`) return res.status(401).json({ error: 'Unauthorized' });
  const { email, full_name = '', business_name = 'Minha Confeitaria', days = 365 } = req.body || {};
  if (!email) return res.status(400).json({ error: 'email é obrigatório' });

  const generatedPassword = password();
  const expires = new Date(); expires.setDate(expires.getDate() + Number(days || 365));
  const expires_at = expires.toISOString().slice(0,10);

  const { data: userData, error: userError } = await supabaseAdmin.auth.admin.createUser({
    email: email.trim().toLowerCase(), password: generatedPassword, email_confirm: true,
    user_metadata: { full_name, business_name }
  });
  if (userError) return res.status(400).json({ error: userError.message });

  const { error: profileError } = await supabaseAdmin.from('profiles').upsert({
    id: userData.user.id, email: email.trim().toLowerCase(), full_name, business_name, active: true, expires_at
  });
  if (profileError) return res.status(500).json({ error: profileError.message });

  // A senha é devolvida somente para o sistema que autorizou a criação.
  // Em produção, o próximo passo é ligar este endpoint ao webhook do pagamento/e-mail transacional.
  return res.status(201).json({
    ok: true, email: email.trim().toLowerCase(), password: generatedPassword, expires_at,
    user_id: userData.user.id
  });
}
